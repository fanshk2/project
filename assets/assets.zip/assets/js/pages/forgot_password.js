function validasi()
{
    if(document.getElementById('v_username').value=='')
    {          
        alert("NIK harus diisi");
        document.getElementById('v_username').focus();
        return false;
    }
    else if(document.getElementById('v_birthday').value=='')
    {          
        alert("Tanggal Lahir harus diisi");
        document.getElementById('v_birthday').focus();
        return false;
    }
}